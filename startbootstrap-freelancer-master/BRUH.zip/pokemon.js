 var HP = 100;
var opponentHP = 100;
 var   inputA = 0;
  var  inputB = 0;
  var opponentHealthMessage = document.getElementById("opponent");
  var myHealthMessage = document.getElementById("mine");
var opponentMoves = ["Ping Pong", "Yeezys", "Red Dress", "Flat Flop"];
var opponentEffect = ["The attack missed!", "The attack was very effective because unlike your pokemon, Infidel Castro has real sneakers.","It's not very effective!","It's super effective!"];
var yourName = prompt("Enter a pokemon name:");
var app = document.getElementById('app');


var typewriter = new Typewriter(app, {
    loop: false,
    typingSpeed: 50,
    deleteSpeed: 25
});

        opponentHealthMessage.textContent=("Infidel Castro has " + opponentHP + " HP.");
    myHealthMessage.textContent=(yourName + " has " + HP + " HP.");


function opponentHealth() {
if (opponentHP <= 0) {
        opponentHP = 
        opponentHealthMessage.textContent=("Infidel Castro has " + opponentHP + " HP.");
    myHealthMessage.textContent=(yourName + " has " + HP + " HP.");
typewriter.pauseFor(800)
    .deleteAll()
    .typeString("Wild Infidel Castro fainted." + " " + yourName + " has gained 100 XP!")
    .pauseFor(800)
    .start();
}

else {}

}

function myHP() {
if (HP <= 0) {
    myHealthMessage.textContent=(yourName + " has " + HP + " HP.");
    console.log(HP)
typewriter.pauseFor(800)
    .deleteAll()
    .typeString(yourName + " fainted. You lost, now go and join Ayinde on the bench.")
    .start();
}

else {}
}

myHP();
opponentHealth();

typewriter.typeString("Wild Infidel Castro appeared!")
    .pauseFor(800)
    .deleteAll()
    .typeString("Go!" + " " + yourName + "!")
    .start();


typewriter.pauseFor(800)
    .deleteAll()
    .typeString("What will" + " " + yourName + " do?")
    .start();


function movesOne(){

    inputA = 1;
    myHP();
opponentHealth();
    typewriter.deleteAll()
    .typeString(yourName + " used Fake Yeezys!")
    .pauseFor(800)
    .deleteAll()
    .typeString("It's not very effective!")
    .start();
    opponentHP = opponentHP - 5;
    myHealthMessage.textContent=(yourName + " has " + HP + " HP.");

    function opponentAttack(){
        myHP();
opponentHealth();
        var randomItem = Math.floor(Math.random()*opponentMoves.length);
var opponentChoice = opponentMoves[randomItem];
var opponentMessage = opponentEffect[randomItem];
if (opponentChoice == opponentMoves[0]){
    HP = HP;
       myHP();
opponentHealth();
}
else if (opponentChoice == opponentMoves[1]){
    HP = HP - 50;
     myHP();
opponentHealth();
}
else if (opponentChoice == opponentMoves[2]){
    HP = HP - 5;
      myHP();
opponentHealth();
}
else {
    HP = HP-40;
       myHP();
opponentHealth();
    
}
        typewriter.pauseFor(800)
        .deleteAll()
        .typeString("Wild Infidel Castro used " + opponentChoice + "!")
        .pauseFor(800)
        .deleteAll()
        .typeString(opponentMessage)
        .pauseFor(800)
        .deleteAll()
        .typeString("What will" + " " + yourName + " do?")
        .start();
        opponentHealthMessage.textContent=("Infidel Castro has " + opponentHP + " HP.");
    myHealthMessage.textContent=(yourName + " has " + HP + " HP.");
    }
    opponentAttack();
   
}

function movesTwo(){
 
    myHP();
opponentHealth();
    typewriter.deleteAll()
    .typeString(yourName + " used Bars!")
    .pauseFor(800)
    .deleteAll()
    .typeString("The attack missed!")
    .start();
    opponentHealthMessage.textContent=("Infidel Castro has " + opponentHP + " HP.");
    myHealthMessage.textContent=(yourName + " has " + HP + " HP.");

     function opponentAttack(){

         myHP();
opponentHealth();
         var randomItem = Math.floor(Math.random()*opponentMoves.length);
var opponentChoice = opponentMoves[randomItem];
var opponentMessage = opponentEffect[randomItem]; if (opponentChoice == opponentMoves[0]){     HP = HP; } else if (opponentChoice == opponentMoves[1]){     HP = HP - 50; } else if (opponentChoice == opponentMoves[2]){     HP = HP - 5; } else {     HP = HP-40; }
         opponentHealthMessage.textContent=("Infidel Castro has " + opponentHP + " HP.");
    document.getElementById("mine").textContent=(yourName + " has " + HP + " HP.");
        typewriter.pauseFor(800)
        .deleteAll()
        .typeString("Wild Infidel Castro used " + opponentChoice + "!")
        .pauseFor(800)
        .deleteAll()
        .typeString(opponentMessage)
        .pauseFor(800)
        .deleteAll()
        .typeString("What will" + " " + yourName + " do?")
        .start();
           opponentHealthMessage.textContent=("Infidel Castro has " + opponentHP + " HP.");
    myHealthMessage.textContent=(yourName + " has " + HP + " HP.");
    }
    opponentAttack();
    }
function movesThree(){

    myHP();
opponentHealth();

    typewriter.deleteAll()
    .typeString(yourName + " used Splash!")
    .pauseFor(800)
    .deleteAll()
    .typeString("It's super effective!")
    .start();
    opponentHP = opponentHP - 60;
   opponentHealthMessage.textContent=("Infidel Castro has " + opponentHP + " HP.");
    myHealthMessage.textContent=(yourName + " has " + HP + " HP.");
    function opponentAttack(){
        myHP();
opponentHealth();
        var randomItem = Math.floor(Math.random()*opponentMoves.length);
var opponentChoice = opponentMoves[randomItem];
var opponentMessage = opponentEffect[randomItem];
if (opponentChoice == opponentMoves[0]){
    HP = HP;
        myHP();
opponentHealth();
}
else if (opponentChoice == opponentMoves[1]){
    HP = HP - 50;
        myHP();
opponentHealth();
}
else if (opponentChoice == opponentMoves[2]){
    HP = HP - 5;
        myHP();
opponentHealth();
}
else {
    HP = HP-40;
       myHP();
opponentHealth();
}
        typewriter.pauseFor(800)
        .deleteAll()
        .typeString("Wild Infidel Castro used " + opponentChoice + "!")
        .pauseFor(800)
        .deleteAll()
        .typeString(opponentMessage)
        .pauseFor(800)
        .deleteAll()
        .typeString("What will" + " " + yourName + " do?")
        .start();
           opponentHealthMessage.textContent=("Infidel Castro has " + opponentHP + " HP.");
    myHealthMessage.textContent=(yourName + " has " + HP + " HP.");
    }
    opponentAttack();
}
function movesFour(){

    myHP();
opponentHealth();

    typewriter.deleteAll()
    .typeString(yourName + " used Protein Shake!")
    .pauseFor(800)
    .deleteAll()
    .typeString(yourName + "'s health was raised by 1 HP!")
    .start();
    opponentHealthMessage.textContent=("Infidel Castro has " + opponentHP + " HP.");
    myHealthMessage.textContent=(yourName + " has " + HP + " HP.");
    if (HP == 100){
        HP = HP;
    }
    else {
        HP = 1 + HP;
        opponentHealthMessage.textContent=("Infidel Castro has " + opponentHP + " HP.");
    myHealthMessage.textContent=(yourName + " has " + HP + " HP.");
    }
       opponentHealthMessage.textContent=("Infidel Castro has " + opponentHP + " HP.");
    myHealthMessage.textContent=(yourName + " has " + HP + " HP.");

    function opponentAttack(){
        myHP();
opponentHealth();
        var randomItem = Math.floor(Math.random()*opponentMoves.length);
var opponentChoice = opponentMoves[randomItem];
var opponentMessage = opponentEffect[randomItem];
if (opponentChoice == opponentMoves[0]){
    HP = HP;
        myHP();
opponentHealth();
}
else if (opponentChoice == opponentMoves[1]){
    HP = HP - 50;
        myHP();
opponentHealth();
}
else if (opponentChoice == opponentMoves[2]){
    HP = HP - 5;
         myHP();
opponentHealth();
}
else {
    HP = HP-40;
        myHP();
opponentHealth();
}
        typewriter.pauseFor(800)
        .deleteAll()
        .typeString("Wild Infidel Castro used " + opponentChoice + "!")
        .pauseFor(800)
        .deleteAll()
        .typeString(opponentMessage)
        .pauseFor(800)
        .deleteAll()
        .typeString("What will" + " " + yourName + " do?")
        .start();
           opponentHealthMessage.textContent=("Infidel Castro has " + opponentHP + " HP.");
    myHealthMessage.textContent=(yourName + " has " + HP + " HP.");
    }
    opponentAttack();

}

   opponentHealthMessage.textContent=("Infidel Castro has " + opponentHP + " HP.");
    myHealthMessage.textContent=(yourName + " has " + HP + " HP.");

setTimeout(function(){ 
    document.getElementById("1").style.visibility= "visible";
}, 7000);

setTimeout(function(){ 
    document.getElementById("2").style.visibility= "visible";

}, 7500);

setTimeout(function(){ 

    document.getElementById("3").style.visibility= "visible";

}, 8000);

setTimeout(function(){ 

    document.getElementById("4").style.visibility= "visible";
}, 8500);
